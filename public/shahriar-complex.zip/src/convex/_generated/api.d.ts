/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as accounting_accounts from "../accounting/accounts.js";
import type * as accounting_charges from "../accounting/charges.js";
import type * as accounting_expenses from "../accounting/expenses.js";
import type * as accounting_fiscal from "../accounting/fiscal.js";
import type * as accounting_invoices from "../accounting/invoices.js";
import type * as accounting_payments from "../accounting/payments.js";
import type * as accounting_reports from "../accounting/reports.js";
import type * as accounting_transfers from "../accounting/transfers.js";
import type * as ai from "../ai.js";
import type * as audit from "../audit.js";
import type * as auth from "../auth.js";
import type * as auth_emailOtp from "../auth/emailOtp.js";
import type * as backup from "../backup.js";
import type * as complex from "../complex.js";
import type * as consultations from "../consultations.js";
import type * as http from "../http.js";
import type * as lib_ledger from "../lib/ledger.js";
import type * as lib_security from "../lib/security.js";
import type * as lib_seq from "../lib/seq.js";
import type * as properties from "../properties.js";
import type * as seed from "../seed.js";
import type * as seedData from "../seedData.js";
import type * as users from "../users.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  "accounting/accounts": typeof accounting_accounts;
  "accounting/charges": typeof accounting_charges;
  "accounting/expenses": typeof accounting_expenses;
  "accounting/fiscal": typeof accounting_fiscal;
  "accounting/invoices": typeof accounting_invoices;
  "accounting/payments": typeof accounting_payments;
  "accounting/reports": typeof accounting_reports;
  "accounting/transfers": typeof accounting_transfers;
  ai: typeof ai;
  audit: typeof audit;
  auth: typeof auth;
  "auth/emailOtp": typeof auth_emailOtp;
  backup: typeof backup;
  complex: typeof complex;
  consultations: typeof consultations;
  http: typeof http;
  "lib/ledger": typeof lib_ledger;
  "lib/security": typeof lib_security;
  "lib/seq": typeof lib_seq;
  properties: typeof properties;
  seed: typeof seed;
  seedData: typeof seedData;
  users: typeof users;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
